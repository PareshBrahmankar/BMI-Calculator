# BMI-Calculator
This is my first basic project 
